# accessing-the-global-scope

use ::member to access global members

