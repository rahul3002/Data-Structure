# alignof

To get the alignment requirements of a type use the alignof keyword or
std::alignment_of<Type>::value.

std::alignment_of<Base>::value == alignof(Base);


