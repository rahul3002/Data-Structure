# char_short-addition

char + char = int

short + short = int
