# final-class

class Final final
 {
public:
virtual void foo();
 };
class Error : public Final // Base 'Final' is marked 'final'
 {

};
