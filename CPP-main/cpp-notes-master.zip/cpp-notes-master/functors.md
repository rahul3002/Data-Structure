# functors

A functor is a class which overloads the operator() method.

class Functor

{

public:

     Functor(){ }

     int operator()

     {

          return 1;

     }

};


