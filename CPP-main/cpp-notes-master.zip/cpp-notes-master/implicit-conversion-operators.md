# implicit-conversion-operators

You can explicitly define conversion operators for classes. 

class Foo

{

     public:

          

          operator double();

};

This would define an explicit conversion from Foo to double.


