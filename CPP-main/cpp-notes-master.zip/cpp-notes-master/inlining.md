# inlining

Declaring a function inline means compilers will replace function calls
with the body of the function. Limit inlining as it produces larger
code. Inlining is a request to the compiler, it must not actually do
it. 

