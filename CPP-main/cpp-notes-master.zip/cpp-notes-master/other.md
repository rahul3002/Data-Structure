# other

-   You can throw exceptions during preprocessing via an #error
    directive

